

import { juegos } from "./array.js";

let container = document.getElementById("container-items");

window.addEventListener('load', function () {
  let juegosAlmacenados = obtenerJuegosDeLocalStorage();

  if (juegosAlmacenados.length > 0) {
      cargarJuegos(juegosAlmacenados);
  } else {
      guardarJuegosEnLocalStorage(juegos);
      cargarJuegos(juegosAlmacenados);
  }
});





function altaCard(juego) {
  let divItem = document.createElement("div");
  divItem.classList.add("items");

  let figure = document.createElement("figure");
  let img = document.createElement("img");
  img.src = juego.imagen;
  img.alt = juego.nombre;
  figure.appendChild(img);

  let divInfo = document.createElement("div");
  divInfo.classList.add("infoProduc");

  let h2 = document.createElement("h2");
  h2.textContent = juego.nombre;

  let h3 = document.createElement("h6");
  h3.classList.add("codigo");
  h3.textContent = juego.codigo;

  let buttonDelete = document.createElement("button")
  buttonDelete.textContent = "Eliminar"
  buttonDelete.addEventListener("click", function() {
    eliminarJuegos(juego.codigo);
  });
 
  let buttonModificar = document.createElement("button");
  buttonModificar.textContent = "Agregar juego";

    // Agregar un event listener para manejar el clic
    buttonModificar.addEventListener("click", function() {
    // Redireccionar a la página deseada
    window.location.href = "./pages/index.html"; // Reemplaza "nueva_pagina.html" con la URL de tu página
    });


  //agregar funciona a button

  divInfo.appendChild(h2);
  divInfo.appendChild(h3);
  divInfo.appendChild(buttonDelete);
  divInfo.appendChild(buttonModificar);
  divItem.appendChild(figure);
  divItem.appendChild(divInfo);

  return divItem;
}



function cargarJuegos(array) {
  container.innerHTML = "";
  array.forEach((juego) => {
    let cardElement = altaCard(juego);
    container.appendChild(cardElement);
  });
}


function guardarJuegosEnLocalStorage(juegos) {
  localStorage.setItem('juegos', JSON.stringify(juegos));
}

function obtenerJuegosDeLocalStorage() {
  let juegosString = localStorage.getItem('juegos');
  return juegosString ? JSON.parse(juegosString) : [];

}








function eliminarJuegos(id) {
  let juegosStorage = obtenerJuegosDeLocalStorage();

  let indice = juegosStorage.findIndex((juego) => juego.codigo === id);

  if (indice !== -1) {
      juegosStorage.splice(indice, 1);

      guardarJuegosEnLocalStorage(juegosStorage);

      cargarJuegos(juegosStorage);

      alert("Producto eliminado correctamente");
  } else {
      alert("No se encontró el producto");
  }
}

