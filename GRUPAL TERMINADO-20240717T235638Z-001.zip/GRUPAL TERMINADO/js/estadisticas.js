let container = document.querySelector(".container");

function obtenerJuegosDeLocalStorage() {
    let JuegosString = localStorage.getItem('juegos');
    return JuegosString ? JSON.parse(JuegosString) : [];
  }

  let juegosLocalStorage = obtenerJuegosDeLocalStorage();
  container.innerHTML = generarTablaJuegos(juegosLocalStorage);
  function generarTablaJuegos(juegos) {
    let tableHTML = '';
    
    if (juegos.length > 0) {
      tableHTML += '<table class="table table-striped border">';
      tableHTML += '<tr>';
      tableHTML += '<th>Tipo de juegos</th>';
      tableHTML += '<th>Precio</th>';
      tableHTML += '<th>Cantidad vendida</th>';
      tableHTML += '<th>Total de ingresos</th>';
      tableHTML += '</tr>';
      
      juegos.forEach(function(juegos) {
        tableHTML += '<tr>';
        tableHTML += '<td>' + juegos.nombre + '</td>';
        tableHTML += '<td>' + juegos.precio + '</td>';
        tableHTML += '<td>' + juegos.cantidadVendida + '</td>';
        tableHTML += '<td>' + (juegos.cantidadVendida * juegos.precio) + '</td>';
        tableHTML += '</tr>';
      });
      
      tableHTML += '</table>';
    } else {
      tableHTML += '<p>No hay productos</p>';
    }
    
    return tableHTML;
  }
