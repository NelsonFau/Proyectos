export class Juego {
    constructor(nombre, precio, imagen, categoria, codigo, cantidadVendida) {
        this.nombre = nombre;
        this.precio = precio;
        this.imagen = imagen;
        this.categoria = categoria;
        this.codigo = codigo;
        this.cantidadVendida = cantidadVendida;
    }
}

