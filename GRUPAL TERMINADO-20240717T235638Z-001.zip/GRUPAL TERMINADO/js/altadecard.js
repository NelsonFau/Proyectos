import { juegos } from "./array.js";
//Alta de juegos en el DOM. Con sus repectivos atributos
let container = document.getElementById("container-items");
const miCarrito = []; 



function mostrarListaJuegos(juegos) {
    container.innerHTML = '';
    document.getElementById("comprarCarrito").addEventListener('click',function () {
        console.log(miCarrito)
        let juegosString = localStorage.getItem('juegos');
        let juegosLS= juegosString ? JSON.parse(juegosString) : [];
        miCarrito.forEach((juegoCarrito)=>{
            let indice=juegosLS.findIndex((juegoLS) =>juegoLS.id===juegoCarrito.id);
            if (juegos[indice].cantidadVendida===undefined){
                juegosLS[indice].cantidadVendida=1
            } else {
                juegosLS[indice].cantidadVendida=parseInt(juegosLS[indice].cantidadVendida) + 1;

            }
            console.log(juegosLS[indice])

        localStorage.setItem('juegos', JSON.stringify(juegosLS));
        })
        

        
        

    });
    console.log()
   
    juegos.forEach((juego) => {
        let divItem = document.createElement("div");
        divItem.classList.add("items");

        let figure = document.createElement("figure");
        let img = document.createElement("img");
        img.src = juego.imagen;
        img.alt = juego.nombre;
        figure.appendChild(img);

        let divInfo = document.createElement("div");
        divInfo.classList.add("infoProduc");

        let h2 = document.createElement("h2");
        h2.textContent = juego.nombre;

        let p = document.createElement("p");
        p.classList.add("price");
        p.textContent = "$" + juego.precio;
    
         //TODO EL CARRITO ACA ABAJO
         let buttonAdd = document.createElement("button");
         buttonAdd.textContent = "Agregar al Carrito";
         buttonAdd.id = juego.id;
         buttonAdd.addEventListener('click', () => {
             miCarrito.push(juego);
             console.log(miCarrito);
             //agregarAlCarrito(juego.id);
             document.getElementById("cantidadUnidadesCarrito").innerHTML=miCarrito.length;
             let totalPrecio=miCarrito.reduce((suma,juego)=>suma+parseInt(juego.precio),0);
             console.log(totalPrecio);
             if (miCarrito.length > 3) {
                 totalPrecio *= 0.85}
             document.getElementById("totalSumaCarrito").innerHTML = totalPrecio;
         });
        
         
            
    
        let h3 = document.createElement("h6");
        h3.classList.add("codigo");
        h3.textContent = juego.codigo;


        divInfo.appendChild(h2);
        divInfo.appendChild(p);
        divInfo.appendChild(h3);
        divInfo.appendChild(buttonAdd);

        divItem.appendChild(figure);
        divItem.appendChild(divInfo);

        container.appendChild(divItem);
    });

}
mostrarListaJuegos(juegos)