import { Juego } from "./juego.js";

document.getElementById('formulario').addEventListener('submit', function (event) {
    event.preventDefault();
    let index = document.getElementById('juegoIndex').value;
    let nombre = document.getElementById('nombre').value;
    let precio = document.getElementById('precio').value;
    let imagen = document.getElementById('imagen').files[0].name;; //document.getElementById("file-id").files[0].name;
    imagen = 'imge/' + imagen;
    let categoria = document.getElementById('categoria').value;
    let codigo = document.getElementById('codigo').value;
    let nuevoJuego = new Juego(nombre, precio, imagen, categoria, codigo);

    let juegos = JSON.parse(localStorage.getItem('juegos') || '[]');

    if (index === 'new') {
        juegos.push(nuevoJuego);
    } else {
        juegos[index] = nuevoJuego;
    }
    localStorage.setItem('juegos', JSON.stringify(juegos));
    alert('Juego procesado con éxito');
    window.location = '../crud.html';
});

window.onload = function () {
    let editData = JSON.parse(localStorage.getItem('editJuego'));
    if (editData) {
        document.get.getElementById('juegoIndex').value = editData.index;
        document.get.getElementById('nombre').value = editData.juego.nombre;
        document.get.getElementById('precio').value = editData.juego.precio;
        document.get.getElementById('imagen').value = editData.juego.imagen;
        document.get.getElementById('categoria').value = editData.juego.categoria;
        document.get.getElementById('codigo').value = editData.juego.codigo;
        localStorage.removeItem('editJuego');
    }
};